# Ghost Comics

Projeto final desenvolvido como avaliação para a matéria de Programação para internet I no Instituto Federal de Brasília
- TSI4V 2023
- Ewerton Bramos
- Igor Michels
- Pedro Henrique